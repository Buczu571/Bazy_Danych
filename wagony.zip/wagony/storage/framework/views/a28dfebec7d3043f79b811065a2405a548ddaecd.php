<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="<?php echo e(asset ('assets/css/indexstyles.css')); ?>" rel="stylesheet">


</head>
<body>
    <h1>Wagony</h1>
    <div class="add-wagon-link">
        <a  href="<?php echo e(route('wagony.create')); ?>">Dodaj wagon</a>
    </div>
    <div>
        <table border="1">
        <tr>
            <th>ID</th>
            <th>Typ</th>
            <th>Klasa</th>
            <th>Miejsca</th>
            <th>Edytuj</th>
            <th>Usun</th>
        </tr>
        <?php $__currentLoopData = $wagony; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wagon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($wagon->id); ?></td>
        <td><?php echo e($wagon->Typ); ?></td>
        <td><?php echo e($wagon->Klasa); ?></td>
        <td><?php echo e($wagon->Miejsca); ?></td>
        <td>
        <a href="<?php echo e(route('wagony.edit', ['wagony' => $wagon->id])); ?>">Edycja</a>
        </td>
        <td>
        <form method="post" action="<?php echo e(route('wagony.destroy', ['wagony' => $wagon->id])); ?>">

            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <input type="submit" value="usun"/>
        </form>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</body>
</html><?php /**PATH D:\xampp\htdocs\wagony\resources\views/wagony/index.blade.php ENDPATH**/ ?>