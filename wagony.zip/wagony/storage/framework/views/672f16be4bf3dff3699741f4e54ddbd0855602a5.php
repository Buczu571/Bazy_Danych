<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="<?php echo e(asset ('assets/css/editstyles.css')); ?>" rel="stylesheet">
</head>
<body>
    <h1>Edytuj wagon</h1>
    <div>
        <?php if($errors->any()): ?>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
            </ul>

        <?php endif; ?>
    </div>
    <form method="post" action="<?php echo e(route('wagony.update', ['wagony' => $wagony])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div>
            <label></label>
            <input type="text" name="Typ" placeholder="Typ" value="<?php echo e($wagony->Typ); ?>"/>
        </div>
        <div>
            <label></label>
            <input type="text" name="Klasa" placeholder="Klasa" value="<?php echo e($wagony->Klasa); ?>"/>
        </div>
        <div>
            <label></label>
            <input type="text" name="Miejsca" placeholder="Miejsca" value="<?php echo e($wagony->Miejsca); ?>"/>
        </div>
        <div class="EdytujWagon">
            <input type="submit" value="Edytuj Wagon">
        </div>
    </form>
</body>
</html><?php /**PATH D:\xampp\htdocs\wagony\resources\views/wagony/edit.blade.php ENDPATH**/ ?>