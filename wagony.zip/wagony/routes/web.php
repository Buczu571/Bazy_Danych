<?php

use Illuminate\Support\Facades\Route;
use   App\Http\Controllers\WagonyController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/wagony', [WagonyController::class, 'index'])->name('wagony.index');
Route::get('/wagony/create', [WagonyController::class, 'create'])->name('wagony.create');
Route::post('/wagony', [WagonyController::class, 'store'])->name('wagony.store');
Route::get('/wagony/{wagony}edit', [WagonyController::class, 'edit'])->name('wagony.edit');
Route::put('/wagony/{wagony}update', [WagonyController::class, 'update'])->name('wagony.update');
Route::delete('/wagony/{wagony}destroy', [WagonyController::class, 'destroy'])->name('wagony.destroy');